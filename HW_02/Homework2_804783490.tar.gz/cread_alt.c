// name: Zhibang Chen
// UID: 804783490


// I used gcc -S -O2 cread_alt.c to compile it.
// there is no jump

long cread_alt(long *xp)
{
    long t=0;
    long *p = xp ? xp : &t;
    return *p;
}
